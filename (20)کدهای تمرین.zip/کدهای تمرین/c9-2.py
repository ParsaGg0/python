a = 1
b = a

a = 14
b = 2

print(a,b)