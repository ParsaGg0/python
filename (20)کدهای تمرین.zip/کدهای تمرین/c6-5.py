n = 1398
shomarande = 0

for maghsoom_alayh_ehtemali in range(1,n+1):
    
    if n % maghsoom_alayh_ehtemali == 0:
        
        shomarande = shomarande + 1
        
        
print(shomarande)