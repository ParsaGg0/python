list1 = [0,1,2,3,4,5,1234]

list1[6] = 0

print(list1)