List1 = [54,12,423,513,45]


List1.pop(0)

print(List1)

List1.pop(0)

print(List1)
