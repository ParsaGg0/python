m = int(input(" mablaghe varizi ra vared konid: "))

print(type(m))

print(m+50)
