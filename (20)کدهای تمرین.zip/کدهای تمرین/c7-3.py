for k in range(1,101,7):
    
    print(k)