list1 = []
shart = True

while(shart):
    
    x = int(input(" in mah chand milion mikhahid dar hesab negah darid? : "))
    list1.append(x)
    
   
    print("----------")
    print(list1)
    print("----------")
    
    

    if len(list1)>=6:
    
        M = sum(list1[-6:])/6
        print("Miyangin = " , M)
        print("----------")
        
        if M>=50:
            
            shart = False
            

            
print("soorate hesab : ")
print(" miyangine 6 mahe akhir : " , M)
print("shoma mitavnid vam begirid! ")
    