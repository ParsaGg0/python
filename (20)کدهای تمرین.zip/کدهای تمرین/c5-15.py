n = 43
J = 0

for k in range(1,n+1):
    
    if n%k == 0:
        
        print(k)
        J = J+k
        
print('-----------------------')
print("jame maghsoom alayhaye " , n , " = " , J)
    