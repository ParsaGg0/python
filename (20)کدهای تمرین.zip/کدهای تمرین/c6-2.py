m = 957

for k in range(3):
    
    print(m%10)
    m = m//10
    