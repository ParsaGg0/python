list1 = [14]
a = int('123')
b = float('1234.56')