list1 = [1,5,13,9,'78']

n = len(list1)

print(len(list1))

print(sum(list1))  # type err