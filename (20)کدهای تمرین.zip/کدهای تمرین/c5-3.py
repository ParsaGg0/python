for k in range(1,1001):  #  k = 1 , 2 , 3 , 4 , ... , 998 , 999 , 1000 
    
    print(5)