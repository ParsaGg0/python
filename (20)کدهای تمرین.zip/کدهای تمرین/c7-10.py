L = [1,2,3,4,5,6]

L.append(1234)
L.append(56)


print(L)