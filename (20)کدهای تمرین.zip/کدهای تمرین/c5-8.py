for k in range(1,28,3):  
    
    print(k)