var_name = input("name : ")
value = input("grade : ")


exec(f"{var_name} = {value}")

print(f"{var_name} = {value}")  # خروجی: 42
