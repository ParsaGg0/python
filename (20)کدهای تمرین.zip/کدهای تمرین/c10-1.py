m = input(" mablaghe varizi ra vared konid: ")
m = int(m)
print(type(m))

print(m+50)