for k in range(9):
    
    print(-k)