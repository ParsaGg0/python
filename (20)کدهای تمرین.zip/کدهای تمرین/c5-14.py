for k in range(16):
    
    print(k-8)