m = 957486

for k in range(15):
    
    print(m%10)
    m = m//10
    