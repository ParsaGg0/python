m = 957
 
print(m%10)  # 7

m = m//10    # (95)

print(m%10)  # 5

m = m//10    # (9)

print(m%10)  # 9

m = m//10    # 0