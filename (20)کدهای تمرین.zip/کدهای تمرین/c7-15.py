list1 = [0,1,2,3,4,5,6,7,8,9]

print(1 in list1)
print(10 in list1)

print(1 not in list1)
print(10 not in list1)


