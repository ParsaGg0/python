for k in range(7,61):  #  k = 1 , 2 , 3 , ... , 59 , 60
    
    print(k)