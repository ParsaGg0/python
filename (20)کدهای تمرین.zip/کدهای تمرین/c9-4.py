n = 7831257941
list1 = []
print(n)

for k in range(10**10):
    
    #print(n)
    list1.append(n%10)
    #print(n%10)
    
    n = n//10
    print(n)
    
    if n==0:
        
        break
        
    
print(list1)

