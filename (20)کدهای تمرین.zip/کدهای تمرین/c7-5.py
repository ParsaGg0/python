list1 = [2,3,5,7,11,13,17,19,'salam',True,13.5,14,15,'kdjfhksdjhfkjsad',454]

print(len(list1))
print('--------------------')

for index in range(0,len(list1)):
    
    print(list1[index])