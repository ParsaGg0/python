for k in range(1,101):
    
    print(101-k)