for k in range(80): 
    
    print(k , end =' ')