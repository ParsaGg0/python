list1 = [0,1,2,3,4,5,6]

print(sum(list1))

s = 0

for k in list1:
    
    s = s+k
    
print(s)