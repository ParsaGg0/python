for k in range(1,14,4):  
    
    print(k)