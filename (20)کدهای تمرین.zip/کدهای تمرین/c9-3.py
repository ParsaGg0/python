list1 = [1.5, 2.5, 7.5]

list2 = []

for k in list1:
    
    list2.append(int(k))
    
    

list2.append(8)

print(list1 , '\n' , list2)
