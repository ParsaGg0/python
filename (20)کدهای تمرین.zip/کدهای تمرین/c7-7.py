s1 = 'abcde'

print(s1[0])
print(s1[1])
