n = 128
T = 0

for k in range(1,n+1):
    
    if n%k == 0:
        
        print(k)
        T = T+1
        
print('-----------------------')
print("tedade maghsoom alayhaye " , n , " = " , T)
    