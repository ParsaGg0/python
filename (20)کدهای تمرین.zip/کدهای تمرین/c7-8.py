list1 = [0,1,2,3,4.5,6.74521,'salam',True,False, [1,2,3,4,[1,2,3,4]]]

# print(len(list1))

print(list1[9])