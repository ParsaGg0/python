riazi = 100
physics = 100
shimi = 100

if riazi>=90 and physics >=85:
    
    print(" Mohandesi computer ghabool shodi! ,  1" )
    
elif shimi>=95 and physics>=80 :
    
    print(" Mohandesi computer ghabool shodi!  , 2 ")
    
elif riazi + physics + shimi >= 240:
    
    print(" Mohandesi computer ghabool shodi!  , 3 ")
    
else :
    
    print(" Mohandesi computer ghabool Nashodi! ")
