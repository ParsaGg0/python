for k in range(12.0): 
    
    print(k)