n = 1000000

for k in range(1,int(n/2)+1):
    
    if n%k == 0:
        
        print(k)
    

print(n)