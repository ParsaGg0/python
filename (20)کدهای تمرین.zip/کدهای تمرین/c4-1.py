nomre_cheshm = 1
ghad = 180
jebhe = 20

if nomre_cheshm > 6 and ghad < 145 :
    
    print (" shoma moaaf shodid! , nomre cheshm ya ghad")
    
elif jebhe >= 48 :
    
    print (" shoma moaaf shodid! , jebhe")
    
else :
    
    print(" shoma moaaf nashodid! ")
