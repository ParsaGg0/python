L = []

print(len(L))

L.append(12)

print(L)