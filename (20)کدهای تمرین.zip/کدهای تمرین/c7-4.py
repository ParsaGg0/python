list1 = [2,3,5,7,11,13,17,19,'salam',True,13.5]

for k in list1:
    
    print(k)