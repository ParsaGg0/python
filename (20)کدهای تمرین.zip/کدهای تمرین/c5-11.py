n = 1000000

for k in range(1,n+1):
    
    if n%k == 0:
        
        print(k)
    