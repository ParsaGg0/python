a = '2 + 3 * 5'
b = eval(a)

name = "ali , 10"