n = 7531
list1 = []

for k in range(10**10):
    
    list1.append(n%10)
    n = n//10
    
    if n==0: 
        break
        
    
print(list1)

s = 0
zarib = 1

for k in range(len(list1)):
    
    s = s + list1[n-1-k]*zarib
    
    print(s)
    
    zarib = zarib * 10
    
print(s)


