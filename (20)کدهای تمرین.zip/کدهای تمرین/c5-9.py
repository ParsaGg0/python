for k in range(1,13,4):  
    
    print(k)