list1 = [1,5,13,9,78]

# print(list1[5])     # index err

# print(list1[2.5])   # type err

# print(list1[2.0])   # type err

# print(list1['2'])     # type err

print(list1[int('2')])
print('-------------')
print(12/6)
print(int(12/6))


