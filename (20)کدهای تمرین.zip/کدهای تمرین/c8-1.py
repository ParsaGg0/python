n = 7981
list1 = []

for k in range(4):
    
    #print(n)
    list1.append(n%10)
    #print(n%10)
    
    n = n//10
    
print(list1)

