a = 9

if a%2==0 :
    print("a zoj ast")
    print("in print dakhele if ast")
    
print(" masale tamam shod!" )






































