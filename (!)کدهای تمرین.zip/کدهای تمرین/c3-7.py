a = 5.0

if type(a)==type(8) or type(a)==type(8.0):
    
    print("a int ya float ast!")