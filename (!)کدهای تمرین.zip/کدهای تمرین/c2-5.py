a = 4
b = -5

if b<=a and  b**2 < a**2 :
    
    print (" ok ")