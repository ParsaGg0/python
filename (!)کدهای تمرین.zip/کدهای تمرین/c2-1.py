print(5%3 == 0 )

print(7/2)
print(7//2)
print(7%2)
print('--------------------')
print(3<=5)
print(3<5)
print(5<5)
print(5==5)
print(5<=5.0)
# print(5=<5)   # Erorr
