a = 1

if a%2==0 or a>10:
    
    print(" a zoj ast ya az 10 bozorgtar ast!")