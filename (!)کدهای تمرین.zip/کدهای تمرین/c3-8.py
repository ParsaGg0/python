a = 10
b = 5
c = 12

if a<(b+c)  and  b<(a+c)  and  c<(a+b):
    
    print(" mosalas tashkil mishavad " )
    
else :
    
    print(" moslas tashkil nemishavad ")