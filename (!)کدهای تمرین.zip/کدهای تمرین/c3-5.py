a = 10
b = 5
c = '5'

if a<(b+c)  and  b<(a+c)  and  c<(a+b):
    
    print(" mosalas tashkil mishavad " )
    
if (b+c)<=a or (a+c)<=b or  (a+b)<=c :
    
    print(" moslas tashkil nemishavad ")