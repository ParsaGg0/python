a = 50+40.0
b = 79

if a>b:
    print('a>b')
    
if a<b:
    print('a<b')

if a==b:
    print('a==b')
    

if (a-b)!= 0 :
    
    print(" a mosavi nist b " )
