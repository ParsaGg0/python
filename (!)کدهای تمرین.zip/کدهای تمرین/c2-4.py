a = 8
b = 7

if a%2==0 and b%2==1 :
    
    print(" a zoj ast va b fard ast!")