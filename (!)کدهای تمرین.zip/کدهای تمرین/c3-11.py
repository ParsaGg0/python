n = 20.5

if n%2 == 0:
    
    print(" n zoj ast!")
    
else:
    
    print(" n fard ast!")