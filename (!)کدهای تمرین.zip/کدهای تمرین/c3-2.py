a = -4.89

b = int(a)

print(b)